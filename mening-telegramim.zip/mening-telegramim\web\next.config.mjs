import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** @type {import('next').NextConfig} */
// Linting runs separately (`npm run lint` at the repo root), not inside `next build`.
const nextConfig = {
  reactStrictMode: true,
  outputFileTracingRoot: path.join(path.dirname(fileURLToPath(import.meta.url)), '..'), eslint: { ignoreDuringBuilds: true } };
export default nextConfig;
